Conway's Game of Life -- Love 2D Engine

Controls:
Left Click: Populate a node
Right Click: Unpopulate a node
P: Start/pause game
C: Clear grid
Up Arrow: Zoom out
Down Arrow: Zoom in

..and an easter egg if you can find it ;)

Enjoy and feel free to contact me with suggestions and feedback!